# FBE 预置：3 个可执行文件走 Android.mk 安装（需要 755）；
# lib64 的 .so 由 vendor_fbe/recovery_root/ 并入 recovery/root（644 足够）。

LOCAL_PATH := $(call my-dir)

ifeq ($(TARGET_DEVICE),tb375fc)

include $(CLEAR_VARS)
LOCAL_MODULE := fbe_android_hardware_security_keymint_3_0_service_beanpod
LOCAL_MODULE_TAGS := optional
LOCAL_MODULE_CLASS := EXECUTABLES
LOCAL_MODULE_PATH := $(TARGET_RECOVERY_ROOT_OUT)/vendor/bin/hw
LOCAL_SRC_FILES := files/bin/hw/android.hardware.security.keymint@3.0-service.beanpod
LOCAL_MODULE_STEM := android.hardware.security.keymint@3.0-service.beanpod
include $(BUILD_PREBUILT)

include $(CLEAR_VARS)
LOCAL_MODULE := fbe_android_hardware_gatekeeper_service_beanpod
LOCAL_MODULE_TAGS := optional
LOCAL_MODULE_CLASS := EXECUTABLES
LOCAL_MODULE_PATH := $(TARGET_RECOVERY_ROOT_OUT)/vendor/bin/hw
LOCAL_SRC_FILES := files/bin/hw/android.hardware.gatekeeper-service.beanpod
LOCAL_MODULE_STEM := android.hardware.gatekeeper-service.beanpod
include $(BUILD_PREBUILT)

include $(CLEAR_VARS)
LOCAL_MODULE := fbe_teei_daemon
LOCAL_MODULE_TAGS := optional
LOCAL_MODULE_CLASS := EXECUTABLES
LOCAL_MODULE_PATH := $(TARGET_RECOVERY_ROOT_OUT)/vendor/bin
LOCAL_SRC_FILES := files/bin/teei_daemon
LOCAL_MODULE_STEM := teei_daemon
include $(BUILD_PREBUILT)

endif
